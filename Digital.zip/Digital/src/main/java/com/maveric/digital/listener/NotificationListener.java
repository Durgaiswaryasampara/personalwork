package com.maveric.digital.listener;

public interface NotificationListener {
    void sendNotification(boolean flag);
}
