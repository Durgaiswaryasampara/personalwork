package com.maveric.digital.model.embedded;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReviewerQuestionWeightage {
  private Integer questionId;
  private String reviewerWeightage;
}
