package com.maveric.digital.responsedto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LineChartDto {
	private String date;
	private Integer count;
}
