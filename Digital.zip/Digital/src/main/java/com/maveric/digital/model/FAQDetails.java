package com.maveric.digital.model;

import lombok.Data;

@Data
public class FAQDetails{
    private String link;
    private String question;
    private String answer;

}
