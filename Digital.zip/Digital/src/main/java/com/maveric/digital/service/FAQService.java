package com.maveric.digital.service;

import com.maveric.digital.responsedto.FAQCategoryDto;

import java.util.List;


public interface FAQService {
List<FAQCategoryDto> getFAQList();
}
