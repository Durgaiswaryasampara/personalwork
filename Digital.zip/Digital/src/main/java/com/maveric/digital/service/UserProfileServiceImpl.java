package com.maveric.digital.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;


import org.springframework.stereotype.Service;
import com.maveric.digital.model.Assessment;
import com.maveric.digital.model.MetricSubmitted;
import com.maveric.digital.model.User;
import com.maveric.digital.model.embedded.AssessmentStatus;
import com.maveric.digital.repository.AssessmentRepository;
import com.maveric.digital.repository.MetricSubmittedRepository;
import com.maveric.digital.repository.UserRepository;
import com.maveric.digital.responsedto.MetricAndAssessmentDetailsDto;
import com.maveric.digital.responsedto.UserProfileDto;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;


@Service
@Slf4j
@RequiredArgsConstructor
public class UserProfileServiceImpl implements UserProfileService{
	
	private final AssessmentRepository assessmentRepository;
	private final MetricSubmittedRepository metricSubmittedRepository;
	private final UserRepository userRepository;
	private final MetricConversationService conversationService;
	private final ConversationService conversationServices;

	@Override
	public UserProfileDto getAssessmentsAndMetricBySubmittedBy(String submittedBy) {
		log.debug("UserProfileServiceImpl::getAssessmentsAndMetricBySubmittedBy()::Start");
	        List<Assessment> assessment= assessmentRepository.findBySubmitStatusInAndSubmittedByOrReviewerId(submittedBy,List.of(AssessmentStatus.SUBMITTED, AssessmentStatus.REVIEWED,AssessmentStatus.SAVE));
	        
	        List<MetricAndAssessmentDetailsDto> assessments =new ArrayList<>();
	        if ( !assessment.isEmpty()) {
	         assessments = conversationServices.toMetricAndAssessmentDetailsDto(assessment);
	        }
	        List<MetricSubmitted> metricSubmitteds = metricSubmittedRepository.findBySubmitStatusInAndSubmittedByOrReviewerId(submittedBy,List.of(AssessmentStatus.SUBMITTED, AssessmentStatus.REVIEWED,AssessmentStatus.SAVE));
	        List<MetricAndAssessmentDetailsDto> metricDetails=new ArrayList<>();
	        if ( !metricSubmitteds.isEmpty()) {
			 metricDetails = conversationService.toMetricSubmitted(metricSubmitteds);
	        }
	        Optional<User> user = userRepository.findByOid(UUID.fromString(submittedBy));
	        UserProfileDto userProfileDto=new UserProfileDto();
	        if(user.isPresent()) {
	        	userProfileDto.setUserDto(conversationServices.convertToUserDto(user.get()));
	        }
			
			userProfileDto.setAssessmentlist(assessments);
			userProfileDto.setMatricsubmitlist(metricDetails);
			log.debug("UserProfileServiceImpl::getAssessmentsAndMetricBySubmittedBy()::End");
			return userProfileDto;
	}
	

}
