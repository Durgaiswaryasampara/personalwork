package com.maveric.digital.repository;

import java.util.List;
import com.maveric.digital.model.embedded.AssessmentStatus;
import java.util.Optional;

import com.maveric.digital.responsedto.ConsulateAccountCountDto;
import com.maveric.digital.responsedto.ReportFilters;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.repository.Aggregation;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.mongodb.repository.Update;
import org.springframework.stereotype.Repository;
import com.maveric.digital.model.Assessment;
import com.maveric.digital.projection.LineChartProjection;
import com.maveric.digital.responsedto.ConsulateProjectCountDto;


@Repository
public interface AssessmentRepository extends MongoRepository<Assessment,Long> {
    List<Assessment> findBySubmittedByOrderByUpdatedAtDesc(String submittedBy);
    List<Assessment> findBySubmittedByAndUpdatedAtBetweenOrderByUpdatedAtDesc(String submittedBy,Long from,Long to);
    List<Assessment> findByUpdatedAtBetweenOrderByUpdatedAtDesc(Long from,Long to);
     List<Assessment> findBySubmittedByAndSubmitStatus(String submittedBy,String submitStatus);
    @Query("{'submitStatus':'SUBMITTED'}")
    List<Assessment> findAllSubmittedAssessmentOrderByUpdatedAtDesc(Sort sort);
    @Query("{'submitStatus': ?0}")
	List<Assessment> findAllAssessmentsBySubmitStatus(String submitStatus);

    @Aggregation(pipeline = {
            "{'$match':{'submittedAt':{'$exists':true}}}",
            "{$group: {'_id': '$project', 'count': {$sum: 1}}}"
    })
    List<ConsulateProjectCountDto> countByProject();


    @Aggregation(pipeline = {
            "{'$match':{'submittedAt':{'$exists':true}}}",
            "{$group: {'_id': '$account', 'count': {$sum: 1}}}"
    })
    List<ConsulateAccountCountDto> countByAccount();
    @Query("{'id':?0,'reviewers.reviewerId':?1}")
    Assessment findAssessmentByAssessmentIdAndReviewerId(Long assessmentId,Integer reviewerId);
    @Aggregation(pipeline = { "{'$match': {'submittedAt':{'$gte':?0,'$lte':?1,'$exists':true},'projectTypeId': ?2 }}",
			"{'$sort':{'submittedAt':1}}",
			"{'$group':{'_id':{'$dateToString':{'format': '%d-%m-%Y','date':{$toDate:'$submittedAt'}}},'count': { '$count': {} }}}" })
	List<LineChartProjection> findLineChartDataByStartAndEndDatesAndProjectTypeId(Long startDate, Long endDate, Long projectTypeId);
     @Aggregation(pipeline = { "{'$match': {'submittedAt':{'$gte':?0,'$lte':?1,'$exists':true},'projectId': {'$in': ?2} }}",
			"{'$sort':{'submittedAt':1}}",
			"{'$group':{'_id':{'$dateToString':{'format': '%d-%m-%Y','date':{$toDate:'$submittedAt'}}},'count': { '$count': {} }}}" })
	List<LineChartProjection> findLineChartDataByStartAndEndDatesInAndProjectId(Long startDate, Long endDate,List<Long> projectId);
     @Aggregation(pipeline = { "{'$match': {'submittedAt':{'$gte':?0,'$lte':?1,'$exists':true},'accountId': ?2 }}",
			"{'$sort':{'submittedAt':1}}",
			"{'$group':{'_id':{'$dateToString':{'format': '%d-%m-%Y','date':{$toDate:'$submittedAt'}}},'count': { '$count': {} }}}" })
	List<LineChartProjection> findLineChartDataByStartAndEndDatesAndAccount(Long startDate, Long endDate,Long accountId);
   @Aggregation(pipeline = { "{'$match': {'submittedAt':{'$gte':?0,'$lte':?1,'$exists':true} }}",
			"{'$sort':{'submittedAt':1}}",
			"{'$group':{'_id':{'$dateToString':{'format': '%d-%m-%Y','date':{$toDate:'$submittedAt'}}},'count': { '$count': {} }}}" })
	List<LineChartProjection> findLineChartDataByStartAndEndDates(Long startDate, Long endDate);
    List<Assessment> findTop5ByOrderByCreatedAtDesc(String submittedBy);
    List<Assessment> findBySubmitStatusInAndSubmittedBy(List<AssessmentStatus> assessmentStatusList, String submittedBy);
    List<Assessment> findTop10BySubmitStatusInOrderByUpdatedAtDesc(List<AssessmentStatus> assessmentStatusList);
    long count();
    Integer countBySubmitStatusIn(List<AssessmentStatus> statusList);
    List<Assessment> findAllBySubmittedByOrderByUpdatedAtDesc(String submittedBy);
    @Query("{'template.id': ?0, 'project.id': ?1}")
    List<Assessment> findByTemplateIdAndProjectId(Long templateId, Long projectId);

  @Query("{'projectCategory.templateQuestionnaire.fileUri': {$regex: ?0}}")
  Optional<Assessment> findAssessmentWithFileUri(String regexPattern);

  List<Assessment> findAllBySubmittedByNotAndSubmitStatusOrderByUpdatedAtDesc(String submittedBy,String submitStatus,Sort sort);

  List<Assessment> findBySubmitStatusIn(List<AssessmentStatus> status,Sort sort);
  @Query("{'businessUnit.id': ?0, 'submitStatus': { $in: ?1 }}")
  List<Assessment> findTop10ByBusinessUnitIdAndSubmitStatusInOrderByUpdatedAtDesc(Long filterValue,List<AssessmentStatus> assessmentStatusList);
  List<Assessment> findTop10ByAccountIdAndSubmitStatusInOrderByUpdatedAtDesc(Long filterValue,List<AssessmentStatus> assessmentStatusList);
  List<Assessment> findTop10ByProjectIdAndSubmitStatusInOrderByUpdatedAtDesc(Long filterValue,List<AssessmentStatus> assessmentStatusList);
  List<Assessment> findTop10ByProjectIdInAndSubmitStatusInOrderByUpdatedAtDesc(List<Long> filterValue,List<AssessmentStatus> assessmentStatusList);
  List<Assessment> findTop10ByProjectTypeIdAndSubmitStatusInOrderByUpdatedAtDesc(Long filterValue,List<AssessmentStatus> assessmentStatusList);


  List<Assessment> findByProjectIdIn(List<Long> id);
  @Query("{'projectType.id' : ?0}")
  List<Assessment> findByProjectTypeId(Long id);
  @Query("{'account.id' : ?0}")
  List<Assessment> findByAccountId(Long id);

    @Query("{'account.id' : ?0,'submitStatus': { $in: ?1 }}")
    List<Assessment> findByAccountIdAndSubmitStatusIn(Long id,List<AssessmentStatus> status);
  List<Assessment> findBySubmitStatusIn(List<AssessmentStatus> status);
  List<Assessment> findByReviewersReviewerIdOrderByUpdatedAtDesc(String reviewerId);


    @Query("{'frequencyReminderDate': { $gte: ?0, $lte: ?1 } }")
    List<Assessment> findByFrequencyReminderDateBetweenAndIsFrequencyRequiredTrue(Long startDate, Long endDate);

    List<Assessment> findByFrequencyOverDueRemindersDateBetweenAndIsFrequencyRequiredTrue(Long startDate, Long endDate);

    @Query(value = "{'id' : ?0}")
    @Update(value = "{'$set': {'frequencyRemindersSent': ?1}}")
    void updateFrequencyRemindersSent(Long id, List<Long> frequencyOverDueRemindersSent);
    @Query("{'submittedBy': ?0,'template.id': ?1, 'project.id': ?2,'id': { $ne: ?4 }}")
    @Update("{'$set': {'isFrequencyRequired': ?3}}")
    void findBySubmittedByAndTemplateIdAndProjectIdAndUpdateisFrequencyRequired(String submittedBy, Long templateId, Long projectId, boolean flag, Long id);


  Integer countByAccountIdAndSubmitStatusEquals(Long accountId, String status);

  Integer countByProjectIdInAndSubmitStatus(List<Long> projectIds, String status);

  Integer countBySubmitStatusEquals(String status);


  @Query("{ $or: [ { 'submittedBy' : ?0 }, { 'reviewers.reviewerId' : ?0 } ], 'submitStatus': { $in: ?1 } }")
  List<Assessment> findBySubmitStatusInAndSubmittedByOrReviewerId(String userId, List<AssessmentStatus> statuses);



    default List<Assessment> findByFilterCriteria(ReportFilters reportFilters) {
        StringBuilder queryBuilder = new StringBuilder("{");
        if (reportFilters.getSubmittedBy() != null) {
            queryBuilder.append("submittedBy: '").append(reportFilters.getSubmittedBy()).append("'").append(",");
        }
        if (reportFilters.getAccountId() != null && reportFilters.getAccountId() != 0) {
            queryBuilder.append("'account.$id':").append(reportFilters.getAccountId()).append(",");
        }

        if (!CollectionUtils.isEmpty(reportFilters.getProjectIds())) {
            queryBuilder.append("'project.$id': { $in: ").append(reportFilters.getProjectIds()).append(" },");
        }

        if (reportFilters.getTemplateId() != null && reportFilters.getTemplateId() != 0) {
            queryBuilder.append(" 'template.$id': ").append(reportFilters.getTemplateId()).append(",");
        }

        if (reportFilters.getSubmissionFromDate() != null&& reportFilters.getSubmissionFromDate()>0 && reportFilters.getSubmissionToDate() != null&& reportFilters.getSubmissionToDate()>0) {
            queryBuilder.append("submittedAt:{");
            queryBuilder.append(" $gte: ").append(reportFilters.getSubmissionFromDate()).append(", ");
            queryBuilder.append("$lte: ").append(reportFilters.getSubmissionToDate());
            queryBuilder.append("},");

        }
        if (reportFilters.getScoreFromRange() != null&& reportFilters.getScoreFromRange()>=0 && reportFilters.getScoreToRange() != null&& reportFilters.getScoreToRange()>0) {
            queryBuilder.append("score:{");
            queryBuilder.append(" $gte: ").append(reportFilters.getScoreFromRange()).append(", ");
            queryBuilder.append("$lte: ").append(reportFilters.getScoreToRange());
            queryBuilder.append("},");

        }

        if (reportFilters.getScoreFromRange() != null && reportFilters.getScoreFromRange() >= 0) {
            queryBuilder.append("score: { $gte: ").append(reportFilters.getScoreFromRange()).append("}, ");
        }

        if (reportFilters.getScoreToRange() != null && reportFilters.getScoreToRange() >= 0) {
            queryBuilder.append("score: { $lte: ").append(reportFilters.getScoreToRange()).append("}, ");
        }

        if (reportFilters.getProjectType() != null && reportFilters.getProjectType() != 0) {
            queryBuilder.append("'projectType.$id': ").append(reportFilters.getProjectType() ).append(",");
        }

        if (StringUtils.isNotBlank(reportFilters.getSubmitStatus())) {
            queryBuilder.append("submitStatus: ").append(reportFilters.getSubmitStatus() ).append(",");
        }

        if (StringUtils.isNotBlank(reportFilters.getReviewedBy())) {
            queryBuilder.append("'reviewers.reviewerId': '").append(reportFilters.getReviewedBy()).append("',");
        }

        if (queryBuilder.charAt(queryBuilder.length() - 1) == ',') {
            queryBuilder.deleteCharAt(queryBuilder.length() - 1);
        }
        queryBuilder.append("}");

        return findByQuery(queryBuilder.toString());
    }

    @Query(value = "?0")
    List<Assessment> findByQuery(String query);

}
