package com.maveric.digital.model.embedded;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReviewerQuestionComment {
	
	private Integer questionId;
	private String reviewerComment;

}
