package com.maveric.digital.responsedto;

public enum ReportFilterType {
    ASSESSMENT,
    METRICS,
    BOTH;
}
