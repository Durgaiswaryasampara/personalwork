package com.maveric.digital.exceptions;

public class SubmitMetricLineChartDataNotFoundException extends AbstractNotFoundException{
    private static final long serialVersionUID = 1L;

    public SubmitMetricLineChartDataNotFoundException(String msg){
        super(msg);
    }
}
