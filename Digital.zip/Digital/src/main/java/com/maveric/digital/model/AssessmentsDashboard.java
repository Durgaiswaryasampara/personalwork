package com.maveric.digital.model;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
public class AssessmentsDashboard {
    private int totalProjects;
    private int totalAssessmentsSaved;
    private int totalAssessmentsSubmission;
    private int totalAssessmentsReviewed;

}