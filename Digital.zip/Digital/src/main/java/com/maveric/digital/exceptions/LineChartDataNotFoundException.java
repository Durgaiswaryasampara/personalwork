package com.maveric.digital.exceptions;

public class LineChartDataNotFoundException extends AbstractNotFoundException {
	private static final long serialVersionUID = 1L;

	public LineChartDataNotFoundException(String message) {
		super(message);
	}

}
