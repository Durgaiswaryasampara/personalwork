package com.maveric.digital.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.maveric.digital.exceptions.AssessmentNotFoundException;
import com.maveric.digital.exceptions.CustomException;
import com.maveric.digital.exceptions.MetricNotFoundException;
import com.maveric.digital.model.Assessment;
import com.maveric.digital.model.MetricSubmitted;
import com.maveric.digital.model.SubmissionFilterDto;
import com.maveric.digital.model.embedded.AssessmentStatus;
import com.maveric.digital.model.embedded.SubmissionHistory;
import com.maveric.digital.repository.AssessmentRepository;
import com.maveric.digital.repository.MetricSubmittedRepository;
import com.maveric.digital.responsedto.AssessmentDto;
import com.maveric.digital.responsedto.MetricSubmittedDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.*;

import static com.maveric.digital.service.ConversationService.ASSESSMENT_NOT_FOUND;
import static com.maveric.digital.service.MetricTemplateServiceImpl.METRIC_NOT_FOUND;
import static com.maveric.digital.utils.ServiceConstants.ZERO;


@Component
@RequiredArgsConstructor
@Slf4j
public class SubmissionHistoryServiceImpl implements SubmissionHistoryService {

    private final AssessmentRepository assessmentRepository;
    private final ConversationService conversationService;
    private final MetricSubmittedRepository metricSubmittedRepository;
    private final MetricConversationService metricConversationService;

    public List<SubmissionHistory> getSubmissionHistory(String submissionFilterRequest) throws JsonProcessingException {
        log.debug("SubmissionHistoryServiceImpl::getSubmissionHistory() call started");
        SubmissionFilterDto submissionFilterDto = conversationService.toSubmissionFilterDtoFromJsonString(submissionFilterRequest);
        List<SubmissionHistory> submissionHistorieList = new ArrayList<>();
        List<Assessment> assessments = switch (evaluateSubmissionFilter(submissionFilterDto)) {
            case SUBMITTED_BY_AND_DATE -> assessmentRepository.findBySubmittedByAndUpdatedAtBetweenOrderByUpdatedAtDesc(submissionFilterDto.getSubmittedBy(), submissionFilterDto.getFromDate(), submissionFilterDto.getToDate());
            case SUBMITTED_BY -> assessmentRepository.findBySubmittedByOrderByUpdatedAtDesc(submissionFilterDto.getSubmittedBy());
            case DATE -> assessmentRepository.findByUpdatedAtBetweenOrderByUpdatedAtDesc(submissionFilterDto.getFromDate(), submissionFilterDto.getToDate());
            case ALL -> assessmentRepository.findAllSubmittedAssessmentOrderByUpdatedAtDesc(Sort.by(Sort.Order.desc("updatedAt")));
        };

        if (CollectionUtils.isEmpty(assessments)) {
            log.error("Assessments not found from DB for provided filters{}", submissionFilterRequest);
            throw new CustomException(String.format("Assessments not found in DB for provided submission filter details %s", submissionFilterRequest), HttpStatus.OK);
        }
        log.debug("Assessments from DB {}", assessments);
        for (Assessment assessment : assessments) {
            SubmissionHistory submissionHistory = new SubmissionHistory();
            submissionHistory.setTemplateName(assessment.getTemplate().getTemplateName());
            submissionHistory.setSubmittedAt(assessment.getSubmittedAt());
            submissionHistory.setSubmittedBy(assessment.getSubmittedBy());
            submissionHistorieList.add(submissionHistory);
        }
        log.debug("SubmissionHistory list {}", submissionHistorieList);
        log.debug("SubmissionHistoryServiceImpl::getSubmissionHistory() call ended");
        return submissionHistorieList;
    }


    private SubmissionFilterType evaluateSubmissionFilter(SubmissionFilterDto submissionFilterDto) {
        boolean hasSubmittedBy = Objects.nonNull(submissionFilterDto.getSubmittedBy()) && !submissionFilterDto.getSubmittedBy().isBlank();
        boolean hasFromDate = submissionFilterDto.getFromDate() > 0;
        boolean hasToDate = submissionFilterDto.getToDate() > 0;
        if (hasSubmittedBy && hasFromDate && hasToDate) {
            return SubmissionFilterType.SUBMITTED_BY_AND_DATE;
        } else if (hasSubmittedBy) {
            return SubmissionFilterType.SUBMITTED_BY;
        } else if (hasFromDate && hasToDate) {
            return SubmissionFilterType.DATE;
        } else {
            return SubmissionFilterType.ALL;
        }
    }

    private enum SubmissionFilterType {
        ALL,
        SUBMITTED_BY_AND_DATE,
        SUBMITTED_BY,
        DATE
    }
    @Override
    public AssessmentDto editSubmittedAssessments(Long id) {
        log.debug("SubmissionHistoryServiceImpl::editSubmittedAssessments() call started");
        Optional<Assessment> assessment=assessmentRepository.findById(id);
        if(assessment.isEmpty()){
            log.error("assessment is not present with the requested ID {}",id );
            throw new AssessmentNotFoundException(ASSESSMENT_NOT_FOUND);
        }
        assessment.get().setSubmitStatus(AssessmentStatus.SAVE);
        assessment.get().setScore(ZERO);
        assessment.get().setCategoryScores(null);
        assessment.get().setFrequencyOverDueRemindersDate(null);
        assessment.get().setFrequencyReminderDate(null);
        assessment.get().setSubmittedAt(null);
        assessmentRepository.save(assessment.get());
        log.debug("SubmissionHistoryServiceImpl::editSubmittedAssessments() call end");
        return conversationService.toAssessmentDto(assessment.get());
    }

    @Override
    public MetricSubmittedDto editSubmittedMetrics(Long id) {
        log.debug("SubmissionHistoryServiceImpl::editSubmittedMetrics() call started");
        Optional<MetricSubmitted> metrics=metricSubmittedRepository.findById(id);
        if(metrics.isEmpty()){
            log.error("metric is not present for the requested ID {}",id);
            throw new MetricNotFoundException(METRIC_NOT_FOUND);
        }
        metrics.get().setSubmitStatus(AssessmentStatus.SAVE);
        metrics.get().setScore(ZERO);
        metrics.get().setCategorywiseScores(null);
        metrics.get().setFrequencyOverDueRemindersDate(null);
        metrics.get().setFrequencyReminderDate(null);
        metrics.get().setSubmittedAt(null);
        metricSubmittedRepository.save(metrics.get());
        log.debug("SubmissionHistoryServiceImpl::editSubmittedMetrics() call started");
        return metricConversationService.toMetricSubmitDto(metrics.get());
    }

}
