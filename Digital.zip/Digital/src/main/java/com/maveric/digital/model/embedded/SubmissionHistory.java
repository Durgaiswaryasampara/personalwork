package com.maveric.digital.model.embedded;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SubmissionHistory {

    private String submittedBy;
    private Long submittedAt;
    private String projectName;
    private String templateName;
    private String clientName;
    private String submitStatus;

}
