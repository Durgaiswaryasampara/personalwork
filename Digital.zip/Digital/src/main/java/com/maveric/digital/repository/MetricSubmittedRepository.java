package com.maveric.digital.repository;

import com.maveric.digital.model.embedded.AssessmentStatus;
import com.maveric.digital.projection.LineChartProjection;
import com.maveric.digital.responsedto.ConsulateAccountCountDto;
import com.maveric.digital.responsedto.ConsulateProjectCountDto;
import com.maveric.digital.responsedto.ReportFilters;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.repository.Aggregation;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.data.mongodb.repository.Update;
import org.springframework.stereotype.Repository;

import com.maveric.digital.model.MetricSubmitted;

import java.util.List;

@Repository
public interface MetricSubmittedRepository extends MongoRepository<MetricSubmitted, Long> {
	@Aggregation(pipeline = {"{'$match': {'submittedAt':{'$gte':?0,'$lte':?1,'$exists':true}, 'projectTypeId': ?2}}",
			"{'$sort':{'submittedAt':1}}",
			"{'$group':{'_id':{'$dateToString':{'format': '%d-%m-%Y','date':{$toDate:'$submittedAt'}}},'count': { '$count': {} }}}"})
	List<LineChartProjection> submitMetricLineChartStartAndEndDatesProjectTypeId(Long startDate, Long endDate, Long projectTypeId);

	@Aggregation(pipeline = {"{'$match': {'submittedAt':{'$gte':?0,'$lte':?1,'$exists':true},'project.$id': {$in: ?2} }}",
			"{'$sort':{'submittedAt':1}}",
			"{'$group':{'_id':{'$dateToString':{'format': '%d-%m-%Y','date':{$toDate:'$submittedAt'}}},'count': { '$count': {} }}}"})
	List<LineChartProjection> submitMetricLineChartStartAndEndDatesAndProjectId(Long startDate, Long endDate, List<Long> projectId);

	@Aggregation(pipeline = {"{'$match': {'submittedAt':{'$gte':?0,'$lte':?1,'$exists':true},'accountId': ?2 }}",
			"{'$sort':{'submittedAt':1}}",
			"{'$group':{'_id':{'$dateToString':{'format': '%d-%m-%Y','date':{$toDate:'$submittedAt'}}},'count': { '$count': {} }}}"})
	List<LineChartProjection> submitMetricLineChartStartAndEndDatesAndAccountId(Long startDate, Long endDate, Long accountId);

	@Aggregation(pipeline = {"{'$match': {'submittedAt':{'$gte':?0,'$lte':?1,'$exists':true} }}",
			"{'$sort':{'submittedAt':1}}",
			"{'$group':{'_id':{'$dateToString':{'format': '%d-%m-%Y','date':{$toDate:'$submittedAt'}}},'count': { '$count': {} }}}"})
	List<LineChartProjection> submitMetricLineChartStartandEndDates(Long startDate, Long endDate);

	Integer countBySubmitStatusIn(List<AssessmentStatus> statusList);

	@Query("{'submitStatus':'SUBMITTED'}")
	List<MetricSubmitted> findAllSubmittedMetricOrderByUpdatedAtDesc(Sort sort);

	List<MetricSubmitted> findAll();
	List<MetricSubmitted> findAllBySubmittedByOrderByUpdatedAtDesc(String submittedBy);
	List<MetricSubmitted> findAllBySubmittedByNotAndSubmitStatusOrderByUpdatedAtDesc(String submittedBy,String submitStatus,Sort sort);
	List<MetricSubmitted> findAllBySubmitStatusNotOrderByUpdatedAtDesc(AssessmentStatus status, Sort sort);
    List<MetricSubmitted> findTop10BySubmitStatusInOrderByUpdatedAtDesc(List<AssessmentStatus> assessmentStatusList);
	@Query("{'businessUnit.id' : ?0}")
	List<MetricSubmitted> findByBusinessUnitId(Long id);
	@Query(value = "{'project.$id': {$in: ?0}}")
	List<MetricSubmitted> findByProjectIds(List<Long> ids);
	@Query("{'projectType.id' : ?0}")
	List<MetricSubmitted> findByProjectTypeId(Long id);
	@Query("{'account.id' : ?0}")
	List<MetricSubmitted> findByAccountId(Long id);
	List<MetricSubmitted> findBySubmitStatusIn(List<AssessmentStatus> status);

	List<MetricSubmitted> findTop10ByAccountIdAndSubmitStatusInOrderByUpdatedAtDesc(Long filterValue,List<AssessmentStatus> assessmentStatusList);
	@Aggregation(pipeline = {"{ '$match': { 'project.$id': { '$in': ?0 }, 'submitStatus': { '$in': ?1 } } }", "{ '$sort': { 'updatedAt': -1 } }", "{ '$limit': 10 }"})
	List<MetricSubmitted> findTop10ByProjectIdInAndSubmitStatusInOrderByUpdatedAtDesc(List<Long> filterValue,List<AssessmentStatus> assessmentStatusList);
	List<MetricSubmitted> findTop10ByProjectTypeIdAndSubmitStatusInOrderByUpdatedAtDesc(Long filterValue,List<AssessmentStatus> assessmentStatusList);
	List<MetricSubmitted> findByReviewersReviewerIdOrderByUpdatedAtDesc(String reviewerId);

	@Aggregation(pipeline = {
			"{'$match':{'submittedAt':{'$exists':true}}}",
			"{$group: {'_id': '$project', 'count': {$sum: 1}}}"
	})
	List<ConsulateProjectCountDto> countByProject();

	@Aggregation(pipeline = {
			"{'$match':{'submittedAt':{'$exists':true}}}",
			"{$group: {'_id': '$account', 'count': {$sum: 1}}}"
	})
	List<ConsulateAccountCountDto> countByAccount();

	@Query("{'submittedBy': ?0,'template.id': ?1, 'project.id': ?2}")
	@Update("{'$set': {'isFrequencyRequired': ?3}}")
	void findBySubmittedByAndTemplateIdAndProjectId(String submittedBy,Long templateId, Long projectId,Boolean flag);

	@Query("{'frequencyReminderDate': { $gte: ?0, $lte: ?1 } }")
	List<MetricSubmitted> findByFrequencyReminderDateBetweenAndIsFrequencyRequiredTrue(Long startDate, Long endDate);
	List<MetricSubmitted> findByFrequencyOverDueRemindersDateBetweenAndIsFrequencyRequiredTrue(Long startDate, Long endDate);

	@Query(value = "{'id' : ?0}")
	@Update(value = "{'$set': {'frequencyRemindersSent': ?1}}")
	void updateFrequencyRemindersSent(Long id, List<Long> frequencyRemindersSent);
	@Query("{'submittedBy': ?0,'template.id': ?1, 'project.id': ?2,'id': { $ne: ?4 }}")
	@Update("{'$set': {'isFrequencyRequired': ?3}}")
	void findBySubmittedByAndTemplateIdAndProjectIdAndUpdatesFrequencyRequired(String submittedBy, Long templateId, Long projectId, boolean flag, Long id);




	Integer countByAccountIdAndSubmitStatusIn(Long accountId, List<String> status);

	@Aggregation(pipeline = {
			"{$match: { 'project.$id': { $in: ?0 }, 'submitStatus': { $in: ?1 } }}",
			"{$group: { 'id': null, 'total': { $sum: 1 } }}"
	})
	Integer countByProjectIdInAndSubmitStatusIn(List<Long> projectIds, List<AssessmentStatus> statuses);
	
	  @Query("{ $or: [ { 'submittedBy' : ?0 }, { 'reviewers.reviewerId' : ?0 } ], 'submitStatus': { $in: ?1 } }")
	  List<MetricSubmitted> findBySubmitStatusInAndSubmittedByOrReviewerId(String userId, List<AssessmentStatus> statuses);

	default List<MetricSubmitted> findByFilterCriteria(ReportFilters reportFilters) {
		StringBuilder queryBuilder = new StringBuilder("{");
		if (reportFilters.getSubmittedBy() != null) {
			queryBuilder.append("submittedBy: '").append(reportFilters.getSubmittedBy()).append("'").append(",");
		}
		if (reportFilters.getAccountId() != null && reportFilters.getAccountId() != 0) {
			queryBuilder.append("'account.$id':").append(reportFilters.getAccountId()).append(",");
		}

		if (!CollectionUtils.isEmpty(reportFilters.getProjectIds())) {
			queryBuilder.append("'project.$id': { $in: ").append(reportFilters.getProjectIds()).append(" },");
		}

		if (reportFilters.getTemplateId() != null && reportFilters.getTemplateId() != 0) {
			queryBuilder.append(" 'template.$id': ").append(reportFilters.getTemplateId()).append(",");
		}

		if (reportFilters.getSubmissionFromDate() != null&& reportFilters.getSubmissionFromDate()>0 && reportFilters.getSubmissionToDate() != null&& reportFilters.getSubmissionToDate()>0) {
			queryBuilder.append("submittedAt:{");
			queryBuilder.append(" $gte: ").append(reportFilters.getSubmissionFromDate()).append(", ");
			queryBuilder.append("$lte: ").append(reportFilters.getSubmissionToDate());
			queryBuilder.append("},");

		}
		if (reportFilters.getScoreFromRange() != null&& reportFilters.getScoreFromRange()>=0 && reportFilters.getScoreToRange() != null&& reportFilters.getScoreToRange()>0) {
			queryBuilder.append("score:{");
			queryBuilder.append(" $gte: ").append(reportFilters.getScoreFromRange()).append(", ");
			queryBuilder.append("$lte: ").append(reportFilters.getScoreToRange());
			queryBuilder.append("},");

		}

		if (reportFilters.getProjectType() != null && reportFilters.getProjectType() != 0) {
			queryBuilder.append("'projectType.$id': ").append(reportFilters.getProjectType() ).append(",");
		}

		if (StringUtils.isNotBlank(reportFilters.getReviewedBy())) {
			queryBuilder.append("'reviewers.reviewerId': '").append(reportFilters.getReviewedBy()).append("',");
		}

		if (org.apache.commons.lang3.StringUtils.isNotBlank(reportFilters.getSubmitStatus())) {
			queryBuilder.append("submitStatus: ").append(reportFilters.getSubmitStatus() ).append(",");
		}
		if (queryBuilder.charAt(queryBuilder.length() - 1) == ',') {
			queryBuilder.deleteCharAt(queryBuilder.length() - 1);
		}


		queryBuilder.append("}");

		return findByQuery(queryBuilder.toString());
	}

	@Query(value = "?0")
	List<MetricSubmitted> findByQuery(String query);
	@Query("{'account.id' : ?0,'submitStatus': { $in: ?1 }}")
	List<MetricSubmitted> findByAccountIdAndSubmitStatusIn(Long id,List<AssessmentStatus> status);
}
