package com.maveric.digital.exceptions;

public class MetricNotFoundException extends AbstractNotFoundException{
    public MetricNotFoundException(String msg){
        super(msg);
    }
}
