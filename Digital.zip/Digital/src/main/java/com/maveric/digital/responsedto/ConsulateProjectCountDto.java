package com.maveric.digital.responsedto;

import com.maveric.digital.model.Project;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ConsulateProjectCountDto {
	Project id;
	Integer count;

}
