package com.maveric.digital.model;

public enum Roles {
    User,
    Reviewer,
    Admin
}
