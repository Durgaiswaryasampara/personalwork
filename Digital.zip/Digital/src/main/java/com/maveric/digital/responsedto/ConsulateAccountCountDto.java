package com.maveric.digital.responsedto;

import com.maveric.digital.model.Account;
import com.maveric.digital.model.Project;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ConsulateAccountCountDto {
	Account id;
	Integer count;

}
