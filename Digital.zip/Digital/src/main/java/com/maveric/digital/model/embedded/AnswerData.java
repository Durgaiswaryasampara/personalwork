package com.maveric.digital.model.embedded;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AnswerData {
	private String lable;
	private String value;
}
