package com.maveric.digital.model.embedded;

public enum Filters {

    PR,
    AC,
    PT
}