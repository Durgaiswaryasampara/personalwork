package com.maveric.digital.service;

import com.maveric.digital.responsedto.UserProfileDto;

public interface UserProfileService {

	
	UserProfileDto getAssessmentsAndMetricBySubmittedBy(String submittedBy);
}
