package com.maveric.digital.exceptions;

public class ConsolidatedDataNotFoundException extends RuntimeException{
    public ConsolidatedDataNotFoundException(String msg){
        super(msg);
    }
}
